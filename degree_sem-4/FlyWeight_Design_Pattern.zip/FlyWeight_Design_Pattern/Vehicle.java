package FlyWeight_Design_Pattern;

public interface Vehicle {
    public void assignColor(String color);
    public void startEngine();
}
