package two;

import one.*;

public class Q15b extends BankC{
    public Q15b() {
        System.out.println("Interest provided by C: " + super.getInterest());
    }
}
