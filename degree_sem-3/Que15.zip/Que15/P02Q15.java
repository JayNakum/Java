import one.*;
import two.*;

public class P02Q15 {
    public static void main(String[] args) {
        new Q15a();
        new Q15b();
    }
}
