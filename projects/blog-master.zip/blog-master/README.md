# blog.xoppa.com

This repository contains sources and assets referenced on [blog.xoppa.com][1]. For more information please visit [that website][1].

## Tutorials

The tutorials folder contains an eclipse project, which contains the assets and runnable tests as referenced on the blog. The eclipse project depends on the [libgdx][2] framework and expects it to be available as eclipse project also. To run the tutorial tests using the stable or nightly builds, you'll need to change the tutorials project accordingly.

 [1]: http://blog.xoppa.com
 [2]: http://libgdx.badlogicgames.com
