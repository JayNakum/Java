
public enum ID {
	
	Player(),
	Zombie(),
	Block(),
	Bullet();

}
