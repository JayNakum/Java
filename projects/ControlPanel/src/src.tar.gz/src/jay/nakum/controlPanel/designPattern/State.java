package jay.nakum.controlPanel.designPattern;

public interface State {
    public void performTask();
}
