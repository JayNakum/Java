package jay.nakum.controlPanel;

import jay.nakum.controlPanel.gui.MainWindow;

public class Main {
    public static void main(String[] args) throws Exception {
        new MainWindow();
    }
}
