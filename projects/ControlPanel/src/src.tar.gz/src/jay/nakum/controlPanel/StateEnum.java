package jay.nakum.controlPanel;

public enum StateEnum {
    None,
    Mute,
    IncreaseVolume,
    DecreaseVolume
}
